﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab07
{
    public abstract class TwoDimShape
    {
        // read-only abstract property Area to calculate the area of the two-dimensional shape. 
        public abstract double Area();
    }
}
